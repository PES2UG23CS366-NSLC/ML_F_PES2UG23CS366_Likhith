# student_lab.py
import torch

def get_entropy_of_dataset(tensor: torch.Tensor):
    """
    Calculate the entropy of the entire dataset.
    """
    # Target column is last
    target_col = tensor[:, -1]
    unique_vals, counts = torch.unique(target_col, return_counts=True)
    probs = counts.float() / counts.sum()
    entropy = -torch.sum(probs * torch.log2(probs + 1e-9))
    return entropy.item()

def get_avg_info_of_attribute(tensor: torch.Tensor, attribute: int):
    """
    Calculate the average information (weighted entropy) of an attribute.
    """
    total_rows = tensor.shape[0]
    unique_vals, counts = torch.unique(tensor[:, attribute], return_counts=True)
    avg_info = 0.0

    for val, count in zip(unique_vals, counts):
        subset_mask = tensor[:, attribute] == val
        subset = tensor[subset_mask]
        subset_entropy = get_entropy_of_dataset(subset)
        weight = count.item() / total_rows
        avg_info += weight * subset_entropy

    return avg_info

def get_information_gain(tensor: torch.Tensor, attribute: int):
    """
    Calculate Information Gain for an attribute.
    """
    dataset_entropy = get_entropy_of_dataset(tensor)
    avg_info = get_avg_info_of_attribute(tensor, attribute)
    info_gain = dataset_entropy - avg_info
    return round(info_gain, 4)

def get_selected_attribute(tensor: torch.Tensor):
    """
    Select the best attribute based on highest information gain.
    """
    num_attributes = tensor.shape[1] - 1  # exclude target
    gains = {}

    for attr in range(num_attributes):
        gains[attr] = get_information_gain(tensor, attr)

    best_attr = max(gains, key=gains.get)
    return gains, best_attr
